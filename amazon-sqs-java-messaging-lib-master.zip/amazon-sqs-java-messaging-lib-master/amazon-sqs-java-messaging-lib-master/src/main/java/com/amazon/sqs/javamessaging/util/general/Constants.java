package com.amazon.sqs.javamessaging.util.general;

import java.io.File;

public class Constants {

    public static final String CONFIG_RESOURCES_PATH = "src" + File.separator + "test" + File.separator + "resources"
            + File.separator + "config" + File.separator;
    public static final String TEMP_RESOURCES_PATH = "target" + File.separator;
}